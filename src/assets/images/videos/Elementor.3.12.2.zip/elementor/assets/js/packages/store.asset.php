<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-store','deps'=>['react','react-dom',],];